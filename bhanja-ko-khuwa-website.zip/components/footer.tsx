import Link from "next/link"
import { MapPin, Phone, Mail, Facebook, Instagram, Clock } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-amber-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-amber-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold">भ</span>
              </div>
              <div>
                <h3 className="text-lg font-bold">भान्जाको खुवा</h3>
                <p className="text-sm text-amber-200">Bhanja Ko Khuwa</p>
              </div>
            </div>
            <p className="text-amber-200 mb-4">
              Authentic Nepali dairy products made with love and tradition. From our family to yours.
            </p>
            <div className="flex space-x-4">
              <Facebook className="w-5 h-5 text-amber-200 hover:text-white cursor-pointer" />
              <Instagram className="w-5 h-5 text-amber-200 hover:text-white cursor-pointer" />
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-amber-200 hover:text-white transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/products" className="text-amber-200 hover:text-white transition-colors">
                  Products
                </Link>
              </li>
              <li>
                <Link href="/order" className="text-amber-200 hover:text-white transition-colors">
                  Order Online
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-amber-200 hover:text-white transition-colors">
                  Blog & Recipes
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-amber-200 hover:text-white transition-colors">
                  FAQ
                </Link>
              </li>
            </ul>
          </div>

          {/* Products */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Our Products</h3>
            <ul className="space-y-2">
              <li>
                <span className="text-amber-200">Premium Khuwa</span>
              </li>
              <li>
                <span className="text-amber-200">Traditional Gudpāk</span>
              </li>
              <li>
                <span className="text-amber-200">Fresh Paneer</span>
              </li>
              <li>
                <span className="text-amber-200">Dairy Sweets</span>
              </li>
              <li>
                <span className="text-amber-200">Custom Orders</span>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <MapPin className="w-4 h-4 text-amber-200" />
                <span className="text-amber-200 text-sm">Kathmandu Valley, Nepal</span>
              </div>
              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4 text-amber-200" />
                <span className="text-amber-200 text-sm">+977-1-XXXXXXX</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4 text-amber-200" />
                <span className="text-amber-200 text-sm">info@bhanjakokhuwa.com</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-amber-200" />
                <span className="text-amber-200 text-sm">Daily: 6:00 AM - 8:00 PM</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-amber-800 mt-8 pt-8 text-center">
          <p className="text-amber-200 text-sm">© 2024 Bhanja Ko Khuwa. All rights reserved. | Made with ❤️ in Nepal</p>
        </div>
      </div>
    </footer>
  )
}
