"use client"

import { useState } from "react"
import Image from "next/image"
import { Filter, Search, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function ProductsPage() {
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [sortBy, setSortBy] = useState("name")

  const products = [
    {
      id: 1,
      name: "Premium Khuwa",
      category: "khuwa",
      description: "Traditional handmade khuwa from fresh buffalo milk",
      price: 450,
      unit: "kg",
      image: "/placeholder.svg?height=300&width=300",
      badge: "Best Seller",
      rating: 4.8,
      inStock: true,
    },
    {
      id: 2,
      name: "Special Gudpāk",
      category: "sweets",
      description: "Sweet delicacy made with pure khuwa and jaggery",
      price: 650,
      unit: "kg",
      image: "/placeholder.svg?height=300&width=300",
      badge: "Traditional",
      rating: 4.9,
      inStock: true,
    },
    {
      id: 3,
      name: "Fresh Paneer",
      category: "dairy",
      description: "Soft cottage cheese made daily from local milk",
      price: 380,
      unit: "kg",
      image: "/placeholder.svg?height=300&width=300",
      badge: "Daily Fresh",
      rating: 4.7,
      inStock: true,
    },
    {
      id: 4,
      name: "Milk Burfi",
      category: "sweets",
      description: "Rich milk-based sweet with cardamom flavor",
      price: 580,
      unit: "kg",
      image: "/placeholder.svg?height=300&width=300",
      badge: "Popular",
      rating: 4.6,
      inStock: true,
    },
    {
      id: 5,
      name: "Organic Khuwa",
      category: "khuwa",
      description: "Made from certified organic milk sources",
      price: 520,
      unit: "kg",
      image: "/placeholder.svg?height=300&width=300",
      badge: "Organic",
      rating: 4.8,
      inStock: false,
    },
    {
      id: 6,
      name: "Chhana",
      category: "dairy",
      description: "Fresh cottage cheese perfect for making sweets",
      price: 320,
      unit: "kg",
      image: "/placeholder.svg?height=300&width=300",
      badge: "Fresh",
      rating: 4.5,
      inStock: true,
    },
    {
      id: 7,
      name: "Rasgulla",
      category: "sweets",
      description: "Soft spongy balls in sugar syrup",
      price: 480,
      unit: "kg",
      image: "/placeholder.svg?height=300&width=300",
      badge: "Festival Special",
      rating: 4.7,
      inStock: true,
    },
    {
      id: 8,
      name: "Flavored Khuwa",
      category: "khuwa",
      description: "Khuwa with traditional flavors like cardamom and saffron",
      price: 480,
      unit: "kg",
      image: "/placeholder.svg?height=300&width=300",
      badge: "Premium",
      rating: 4.6,
      inStock: true,
    },
  ]

  const categories = [
    { value: "all", label: "All Products" },
    { value: "khuwa", label: "Khuwa" },
    { value: "sweets", label: "Dairy Sweets" },
    { value: "dairy", label: "Fresh Dairy" },
  ]

  const filteredProducts = products
    .filter((product) => {
      const matchesCategory = selectedCategory === "all" || product.category === selectedCategory
      const matchesSearch =
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.description.toLowerCase().includes(searchTerm.toLowerCase())
      return matchesCategory && matchesSearch
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "price-low":
          return a.price - b.price
        case "price-high":
          return b.price - a.price
        case "rating":
          return b.rating - a.rating
        default:
          return a.name.localeCompare(b.name)
      }
    })

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-50">
      {/* Header */}
      <section className="py-12 px-4 bg-gradient-to-r from-amber-100 to-orange-100">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-amber-900 mb-4">Our Products</h1>
          <p className="text-lg text-amber-800 max-w-2xl mx-auto">
            Discover our complete range of authentic Nepali dairy products, made with love and traditional methods
          </p>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 px-4 bg-white border-b">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="flex flex-col sm:flex-row gap-4 items-center">
              <div className="flex items-center gap-2">
                <Filter className="w-5 h-5 text-amber-700" />
                <span className="font-semibold text-amber-900">Filter:</span>
              </div>

              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.value} value={category.value}>
                      {category.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-amber-600" />
                <Input
                  placeholder="Search products..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
            </div>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">Name (A-Z)</SelectItem>
                <SelectItem value="price-low">Price (Low to High)</SelectItem>
                <SelectItem value="price-high">Price (High to Low)</SelectItem>
                <SelectItem value="rating">Rating (High to Low)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-12 px-4">
        <div className="max-w-6xl mx-auto">
          {filteredProducts.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-xl text-amber-700">No products found matching your criteria.</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <Card
                  key={product.id}
                  className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg bg-white"
                >
                  <CardContent className="p-0">
                    <div className="relative overflow-hidden rounded-t-lg">
                      <Image
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        width={300}
                        height={300}
                        className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute top-3 left-3">
                        <span className="bg-orange-600 text-white px-2 py-1 rounded-full text-xs font-semibold">
                          {product.badge}
                        </span>
                      </div>
                      {!product.inStock && (
                        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                          <span className="bg-red-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
                            Out of Stock
                          </span>
                        </div>
                      )}
                    </div>
                    <div className="p-4">
                      <h3 className="text-lg font-bold text-amber-900 mb-2">{product.name}</h3>
                      <p className="text-amber-700 text-sm mb-3 line-clamp-2">{product.description}</p>

                      <div className="flex items-center gap-1 mb-3">
                        <Star className="w-4 h-4 fill-orange-400 text-orange-400" />
                        <span className="text-sm text-amber-700">{product.rating}</span>
                      </div>

                      <div className="flex justify-between items-center">
                        <div>
                          <span className="text-xl font-bold text-orange-600">NPR {product.price}</span>
                          <span className="text-sm text-amber-600">/{product.unit}</span>
                        </div>
                        <Button size="sm" className="bg-orange-600 hover:bg-orange-700" disabled={!product.inStock}>
                          {product.inStock ? "Order Now" : "Notify Me"}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 px-4 bg-gradient-to-r from-orange-600 to-amber-600 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Can't Find What You're Looking For?</h2>
          <p className="text-xl mb-6 opacity-90">
            We also take custom orders for special occasions and bulk requirements
          </p>
          <Button size="lg" className="bg-white text-orange-600 hover:bg-gray-100">
            Contact Us for Custom Orders
          </Button>
        </div>
      </section>
    </div>
  )
}
