import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export const metadata = {
  title: "FAQ - Bhanja Ko Khuwa | Frequently Asked Questions",
  description:
    "Find answers to common questions about our products, delivery, storage, and ordering process. Get quick help for your dairy product inquiries.",
}

export default function FAQPage() {
  const faqCategories = [
    {
      title: "Products & Quality",
      faqs: [
        {
          question: "What makes your khuwa different from others?",
          answer:
            "Our khuwa is made using traditional methods passed down through three generations. We use only fresh, high-quality milk from local farms and cook it slowly in copper vessels without any artificial preservatives or additives. This traditional approach gives our khuwa its authentic taste and superior quality.",
        },
        {
          question: "How long does khuwa last and how should I store it?",
          answer:
            "Fresh khuwa can be stored in the refrigerator for up to 5-7 days. For longer storage, you can freeze it for up to 3 months. Always store in airtight containers and avoid exposure to moisture. For best taste, consume within 3 days of purchase.",
        },
        {
          question: "Do you use any preservatives in your products?",
          answer:
            "No, we don't use any artificial preservatives, colors, or additives in our products. All our dairy items are made using natural ingredients and traditional methods, ensuring you get pure, authentic taste.",
        },
        {
          question: "What is the difference between regular and organic khuwa?",
          answer:
            "Our organic khuwa is made from milk sourced from certified organic farms where cows are fed organic feed and no synthetic hormones or antibiotics are used. Regular khuwa uses high-quality local milk that meets our strict quality standards but may not be certified organic.",
        },
      ],
    },
    {
      title: "Ordering & Delivery",
      faqs: [
        {
          question: "What areas do you deliver to?",
          answer:
            "We currently deliver within the Kathmandu Valley, including Kathmandu, Lalitpur, and Bhaktapur districts. We're working to expand our delivery area to serve more customers across Nepal.",
        },
        {
          question: "How long does delivery take?",
          answer:
            "For orders within Kathmandu Valley, we typically deliver within 1-2 business days. Same-day delivery is available for orders placed before 10 AM, subject to availability and location.",
        },
        {
          question: "What is the minimum order amount for delivery?",
          answer:
            "The minimum order amount for home delivery is NPR 500. Orders below this amount can be picked up from our store or combined with other items to meet the minimum requirement.",
        },
        {
          question: "Can I schedule a delivery for a specific time?",
          answer:
            "Yes, we offer scheduled delivery slots. You can choose your preferred time slot during checkout, and we'll do our best to deliver within that window. Please note that exact timing may vary due to traffic and other factors.",
        },
      ],
    },
    {
      title: "Payment & Pricing",
      faqs: [
        {
          question: "What payment methods do you accept?",
          answer:
            "We accept Cash on Delivery (COD), eSewa, Khalti, and bank transfers. For online payments, you'll receive a confirmation once the payment is processed successfully.",
        },
        {
          question: "Are there any additional charges for delivery?",
          answer:
            "Yes, we charge NPR 100 for home delivery within Kathmandu Valley. Delivery is free for orders above NPR 2000 or if you choose store pickup.",
        },
        {
          question: "Do you offer bulk discounts?",
          answer:
            "Yes, we offer special pricing for bulk orders (5kg or more) and for regular customers. Please contact us directly to discuss bulk pricing and custom requirements.",
        },
        {
          question: "Can I get a refund if I'm not satisfied?",
          answer:
            "We stand behind the quality of our products. If you're not satisfied with your purchase, please contact us within 24 hours of delivery, and we'll work to resolve the issue or provide a replacement.",
        },
      ],
    },
    {
      title: "Custom Orders & Special Requests",
      faqs: [
        {
          question: "Do you take custom orders for special occasions?",
          answer:
            "Yes, we specialize in custom orders for festivals, weddings, and special events. We can prepare specific quantities and even customize packaging. Please place custom orders at least 3-5 days in advance.",
        },
        {
          question: "Can you make sugar-free or low-fat versions?",
          answer:
            "We can prepare low-fat versions of some products using skimmed milk. For sugar-free sweets, we can use natural sweeteners like jaggery or dates. Please discuss your specific requirements when placing the order.",
        },
        {
          question: "Do you cater to dietary restrictions?",
          answer:
            "We can accommodate certain dietary restrictions. Our products are naturally vegetarian, and we can prepare vegan alternatives using plant-based milk for some items. Please inform us about any allergies or dietary requirements when ordering.",
        },
      ],
    },
    {
      title: "About Our Process",
      faqs: [
        {
          question: "Where do you source your milk from?",
          answer:
            "We source fresh milk daily from trusted local farms in the Kathmandu Valley. All our suppliers follow strict hygiene standards and provide high-quality milk from healthy, well-cared-for animals.",
        },
        {
          question: "How do you ensure product quality and hygiene?",
          answer:
            "We follow strict hygiene protocols throughout our production process. Our facility is regularly cleaned and sanitized, all staff follow proper hygiene practices, and we conduct regular quality checks on both raw materials and finished products.",
        },
        {
          question: "Can I visit your production facility?",
          answer:
            "Yes, we welcome customers to visit our store and see our production process. Please call ahead to schedule a visit, and we'll be happy to show you how we make our traditional dairy products.",
        },
      ],
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-50">
      {/* Header */}
      <section className="py-12 px-4 bg-gradient-to-r from-amber-100 to-orange-100">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-amber-900 mb-4">Frequently Asked Questions</h1>
          <p className="text-lg text-amber-800 max-w-2xl mx-auto">
            Find quick answers to common questions about our products, ordering, and services
          </p>
        </div>
      </section>

      <div className="max-w-4xl mx-auto px-4 py-12">
        {faqCategories.map((category, categoryIndex) => (
          <Card key={categoryIndex} className="mb-8 border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl text-amber-900 flex items-center gap-2">
                <div className="w-8 h-8 bg-orange-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                  {categoryIndex + 1}
                </div>
                {category.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="space-y-2">
                {category.faqs.map((faq, faqIndex) => (
                  <AccordionItem
                    key={faqIndex}
                    value={`${categoryIndex}-${faqIndex}`}
                    className="border border-amber-200 rounded-lg px-4"
                  >
                    <AccordionTrigger className="text-left text-amber-900 hover:text-orange-600 hover:no-underline">
                      <span className="font-semibold">{faq.question}</span>
                    </AccordionTrigger>
                    <AccordionContent className="text-amber-700 leading-relaxed pt-2">{faq.answer}</AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        ))}

        {/* Contact Section */}
        <Card className="border-0 shadow-xl bg-gradient-to-r from-orange-600 to-amber-600 text-white">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Still Have Questions?</h2>
            <p className="text-lg mb-6 opacity-90">Can't find what you're looking for? We're here to help!</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="tel:+977-1-XXXXXXX"
                className="bg-white text-orange-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
              >
                Call Us: +977-1-XXXXXXX
              </a>
              <a
                href="mailto:info@bhanjakokhuwa.com"
                className="bg-white text-orange-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
              >
                Email: info@bhanjakokhuwa.com
              </a>
            </div>
            <p className="text-sm opacity-75 mt-4">
              Our customer service team is available during business hours to assist you
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
