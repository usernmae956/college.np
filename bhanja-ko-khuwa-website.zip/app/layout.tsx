import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Bhanja Ko Khuwa - Authentic Nepali Dairy Products | Traditional Khuwa & Gudpāk",
  description:
    "Premium quality traditional Nepali dairy products including handmade khuwa, gudpāk, and fresh dairy items. Made with love using time-honored methods. Order online for delivery across Kathmandu Valley.",
  keywords:
    "khuwa, gudpak, nepali dairy, traditional dairy products, kathmandu, nepal, fresh milk products, handmade dairy",
  authors: [{ name: "Bhanja Ko Khuwa" }],
  openGraph: {
    title: "Bhanja Ko Khuwa - Authentic Nepali Dairy Products",
    description: "Premium quality traditional Nepali dairy products made with love and tradition",
    type: "website",
    locale: "en_US",
    siteName: "Bhanja Ko Khuwa",
  },
  twitter: {
    card: "summary_large_image",
    title: "Bhanja Ko Khuwa - Authentic Nepali Dairy Products",
    description: "Premium quality traditional Nepali dairy products made with love and tradition",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <link rel="canonical" href="https://bhanjakokhuwa.com" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "LocalBusiness",
              name: "Bhanja Ko Khuwa",
              description: "Traditional Nepali dairy products including khuwa, gudpāk, and fresh dairy items",
              address: {
                "@type": "PostalAddress",
                streetAddress: "Kathmandu Valley",
                addressLocality: "Kathmandu",
                addressCountry: "Nepal",
              },
              telephone: "+977-1-XXXXXXX",
              url: "https://bhanjakokhuwa.com",
              priceRange: "$$",
              servesCuisine: "Nepali Dairy Products",
              openingHours: "Mo-Su 06:00-20:00",
            }),
          }}
        />
      </head>
      <body className={inter.className}>
        <Header />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  )
}
