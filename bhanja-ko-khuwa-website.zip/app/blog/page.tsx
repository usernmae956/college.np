import Image from "next/image"
import Link from "next/link"
import { Calendar, User, ArrowRight, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export const metadata = {
  title: "Blog & Recipes - Bhanja Ko Khuwa | Traditional Nepali Dairy Insights",
  description:
    "Discover traditional Nepali dairy recipes, cooking tips, and insights into our dairy-making process. Learn about khuwa, gudpāk, and other authentic dairy products.",
}

export default function BlogPage() {
  const featuredPost = {
    id: 1,
    title: "The Art of Making Traditional Khuwa: A Step-by-Step Guide",
    excerpt:
      "Discover the ancient techniques behind Nepal's most beloved dairy product. Learn how our family has perfected the art of khuwa-making over three generations.",
    image: "/placeholder.svg?height=400&width=600",
    author: "Bhanja Ko Khuwa Team",
    date: "2024-01-15",
    readTime: "8 min read",
    category: "Traditional Methods",
    slug: "art-of-making-traditional-khuwa",
  }

  const blogPosts = [
    {
      id: 2,
      title: "5 Delicious Gudpāk Recipes for Festival Season",
      excerpt:
        "Celebrate Nepali festivals with these traditional gudpāk variations that have been passed down through generations.",
      image: "/placeholder.svg?height=300&width=400",
      author: "Maya Gurung",
      date: "2024-01-10",
      readTime: "6 min read",
      category: "Recipes",
      slug: "gudpak-recipes-festival-season",
    },
    {
      id: 3,
      title: "Health Benefits of Traditional Dairy Products",
      excerpt:
        "Explore the nutritional advantages of consuming traditional dairy products like khuwa and fresh paneer.",
      image: "/placeholder.svg?height=300&width=400",
      author: "Dr. Ram Sharma",
      date: "2024-01-08",
      readTime: "5 min read",
      category: "Health & Nutrition",
      slug: "health-benefits-traditional-dairy",
    },
    {
      id: 4,
      title: "From Farm to Table: Our Quality Assurance Process",
      excerpt:
        "Take a behind-the-scenes look at how we ensure the highest quality from milk collection to final product delivery.",
      image: "/placeholder.svg?height=300&width=400",
      author: "Bhanja Ko Khuwa Team",
      date: "2024-01-05",
      readTime: "7 min read",
      category: "Quality & Process",
      slug: "farm-to-table-quality-assurance",
    },
    {
      id: 5,
      title: "Preserving Khuwa: Traditional vs Modern Methods",
      excerpt:
        "Learn about different preservation techniques and how to store your khuwa to maintain its freshness and flavor.",
      image: "/placeholder.svg?height=300&width=400",
      author: "Sita Sharma",
      date: "2024-01-03",
      readTime: "4 min read",
      category: "Tips & Tricks",
      slug: "preserving-khuwa-methods",
    },
    {
      id: 6,
      title: "The Cultural Significance of Dairy in Nepali Cuisine",
      excerpt:
        "Explore how dairy products like khuwa and paneer play a central role in Nepali culture and traditional celebrations.",
      image: "/placeholder.svg?height=300&width=400",
      author: "Prof. Krishna Bahadur",
      date: "2024-01-01",
      readTime: "9 min read",
      category: "Culture & Tradition",
      slug: "cultural-significance-dairy-nepali-cuisine",
    },
    {
      id: 7,
      title: "Seasonal Dairy Delights: What to Expect Throughout the Year",
      excerpt:
        "Discover how different seasons affect dairy production and which products are best enjoyed at different times of the year.",
      image: "/placeholder.svg?height=300&width=400",
      author: "Bhanja Ko Khuwa Team",
      date: "2023-12-28",
      readTime: "6 min read",
      category: "Seasonal Guide",
      slug: "seasonal-dairy-delights",
    },
  ]

  const categories = [
    "All Posts",
    "Recipes",
    "Traditional Methods",
    "Health & Nutrition",
    "Quality & Process",
    "Tips & Tricks",
    "Culture & Tradition",
    "Seasonal Guide",
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-50">
      {/* Header */}
      <section className="py-12 px-4 bg-gradient-to-r from-amber-100 to-orange-100">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-amber-900 mb-4">Blog & Recipes</h1>
          <p className="text-lg text-amber-800 max-w-2xl mx-auto">
            Discover traditional recipes, dairy-making insights, and the rich culture behind Nepal's finest dairy
            products
          </p>
        </div>
      </section>

      <div className="max-w-6xl mx-auto px-4 py-12">
        {/* Featured Post */}
        <section className="mb-16">
          <Card className="overflow-hidden border-0 shadow-2xl">
            <div className="grid lg:grid-cols-2">
              <div className="relative h-64 lg:h-auto">
                <Image
                  src={featuredPost.image || "/placeholder.svg"}
                  alt={featuredPost.title}
                  fill
                  className="object-cover"
                />
                <div className="absolute top-4 left-4">
                  <Badge className="bg-orange-600 text-white">Featured</Badge>
                </div>
              </div>
              <CardContent className="p-8 flex flex-col justify-center">
                <div className="mb-4">
                  <Badge variant="outline" className="border-orange-600 text-orange-600">
                    {featuredPost.category}
                  </Badge>
                </div>
                <h2 className="text-2xl md:text-3xl font-bold text-amber-900 mb-4">{featuredPost.title}</h2>
                <p className="text-amber-700 mb-6 leading-relaxed">{featuredPost.excerpt}</p>
                <div className="flex items-center gap-4 text-sm text-amber-600 mb-6">
                  <div className="flex items-center gap-1">
                    <User className="w-4 h-4" />
                    <span>{featuredPost.author}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    <span>{new Date(featuredPost.date).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    <span>{featuredPost.readTime}</span>
                  </div>
                </div>
                <Button asChild className="bg-orange-600 hover:bg-orange-700 w-fit">
                  <Link href={`/blog/${featuredPost.slug}`}>
                    Read Full Article
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Link>
                </Button>
              </CardContent>
            </div>
          </Card>
        </section>

        {/* Categories Filter */}
        <section className="mb-12">
          <div className="flex flex-wrap gap-2 justify-center">
            {categories.map((category) => (
              <Button
                key={category}
                variant="outline"
                size="sm"
                className="border-orange-600 text-orange-600 hover:bg-orange-50 bg-transparent"
              >
                {category}
              </Button>
            ))}
          </div>
        </section>

        {/* Blog Posts Grid */}
        <section>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <Card
                key={post.id}
                className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg bg-white"
              >
                <CardContent className="p-0">
                  <div className="relative overflow-hidden rounded-t-lg">
                    <Image
                      src={post.image || "/placeholder.svg"}
                      alt={post.title}
                      width={400}
                      height={300}
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-3 left-3">
                      <Badge variant="outline" className="bg-white/90 border-orange-600 text-orange-600">
                        {post.category}
                      </Badge>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-amber-900 mb-3 line-clamp-2 group-hover:text-orange-600 transition-colors">
                      {post.title}
                    </h3>
                    <p className="text-amber-700 mb-4 line-clamp-3">{post.excerpt}</p>
                    <div className="flex items-center gap-3 text-xs text-amber-600 mb-4">
                      <div className="flex items-center gap-1">
                        <User className="w-3 h-3" />
                        <span>{post.author}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        <span>{new Date(post.date).toLocaleDateString()}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>{post.readTime}</span>
                      </div>
                    </div>
                    <Button
                      asChild
                      variant="outline"
                      size="sm"
                      className="border-orange-600 text-orange-600 hover:bg-orange-50 bg-transparent"
                    >
                      <Link href={`/blog/${post.slug}`}>
                        Read More
                        <ArrowRight className="w-3 h-3 ml-2" />
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Newsletter Signup */}
        <section className="mt-16">
          <Card className="border-0 shadow-xl bg-gradient-to-r from-orange-600 to-amber-600 text-white">
            <CardContent className="p-8 text-center">
              <h2 className="text-3xl font-bold mb-4">Stay Updated with Our Latest Recipes</h2>
              <p className="text-xl mb-6 opacity-90">
                Get traditional Nepali dairy recipes and cooking tips delivered to your inbox
              </p>
              <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
                <input
                  type="email"
                  placeholder="Enter your email address"
                  className="flex-1 px-4 py-2 rounded-lg text-amber-900 placeholder-amber-600"
                />
                <Button className="bg-white text-orange-600 hover:bg-gray-100">Subscribe</Button>
              </div>
              <p className="text-sm opacity-75 mt-4">No spam, just delicious recipes and dairy insights!</p>
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  )
}
