import { MapPin, Phone, Mail, Clock, MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

export const metadata = {
  title: "Contact Us - Bhanja Ko Khuwa | Get in Touch for Orders & Inquiries",
  description:
    "Contact Bhanja Ko Khuwa for orders, inquiries, and customer support. Visit our store in Kathmandu Valley or reach us via phone, email, or WhatsApp.",
}

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-50">
      {/* Header */}
      <section className="py-12 px-4 bg-gradient-to-r from-amber-100 to-orange-100">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-amber-900 mb-4">Contact Us</h1>
          <p className="text-lg text-amber-800">
            We'd love to hear from you. Get in touch for orders, questions, or just to say hello!
          </p>
        </div>
      </section>

      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div className="space-y-8">
            <div>
              <h2 className="text-3xl font-bold text-amber-900 mb-6">Get in Touch</h2>
              <p className="text-lg text-amber-800 mb-8">
                Whether you have questions about our products, want to place a custom order, or need assistance with
                delivery, we're here to help!
              </p>
            </div>

            {/* Contact Cards */}
            <div className="space-y-6">
              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                      <MapPin className="w-6 h-6 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-amber-900 mb-2">Visit Our Store</h3>
                      <p className="text-amber-700 mb-2">
                        Kathmandu Valley, Nepal
                        <br />
                        Near Local Market Area
                      </p>
                      <p className="text-sm text-amber-600">
                        Come visit us to see our production process and taste fresh samples!
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                      <Phone className="w-6 h-6 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-amber-900 mb-2">Call Us</h3>
                      <p className="text-amber-700 mb-2">
                        +977-1-XXXXXXX
                        <br />
                        +977-98XXXXXXXX (Mobile)
                      </p>
                      <p className="text-sm text-amber-600">
                        Call us for immediate assistance or to place phone orders
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                      <Mail className="w-6 h-6 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-amber-900 mb-2">Email Us</h3>
                      <p className="text-amber-700 mb-2">
                        info@bhanjakokhuwa.com
                        <br />
                        orders@bhanjakokhuwa.com
                      </p>
                      <p className="text-sm text-amber-600">Send us detailed inquiries or custom order requests</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                      <Clock className="w-6 h-6 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-amber-900 mb-2">Business Hours</h3>
                      <div className="text-amber-700 space-y-1">
                        <p>Monday - Saturday: 6:00 AM - 8:00 PM</p>
                        <p>Sunday: 7:00 AM - 6:00 PM</p>
                      </div>
                      <p className="text-sm text-amber-600 mt-2">
                        Fresh products available daily during business hours
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                      <MessageCircle className="w-6 h-6 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-amber-900 mb-2">WhatsApp</h3>
                      <p className="text-amber-700 mb-2">+977-98XXXXXXXX</p>
                      <p className="text-sm text-amber-600">Quick orders and instant communication via WhatsApp</p>
                      <Button size="sm" className="mt-3 bg-green-600 hover:bg-green-700">
                        Chat on WhatsApp
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Contact Form */}
          <div>
            <Card className="border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="text-2xl text-amber-900">Send us a Message</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">First Name *</Label>
                    <Input id="firstName" placeholder="Your first name" />
                  </div>
                  <div>
                    <Label htmlFor="lastName">Last Name *</Label>
                    <Input id="lastName" placeholder="Your last name" />
                  </div>
                </div>

                <div>
                  <Label htmlFor="email">Email Address *</Label>
                  <Input id="email" type="email" placeholder="your.email@example.com" />
                </div>

                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input id="phone" placeholder="+977-XXXXXXXXX" />
                </div>

                <div>
                  <Label htmlFor="subject">Subject *</Label>
                  <Input id="subject" placeholder="What is this regarding?" />
                </div>

                <div>
                  <Label htmlFor="message">Message *</Label>
                  <Textarea id="message" placeholder="Tell us how we can help you..." className="min-h-[120px]" />
                </div>

                <Button className="w-full bg-orange-600 hover:bg-orange-700 text-white">Send Message</Button>

                <p className="text-sm text-amber-600 text-center">
                  We typically respond within 24 hours during business days
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Map Section */}
        <div className="mt-16">
          <Card className="border-0 shadow-xl">
            <CardHeader>
              <CardTitle className="text-2xl text-amber-900 text-center">Find Us</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="aspect-video bg-amber-100 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="w-12 h-12 text-orange-600 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-amber-900 mb-2">Bhanja Ko Khuwa</h3>
                  <p className="text-amber-700">Kathmandu Valley, Nepal</p>
                  <p className="text-sm text-amber-600 mt-2">Interactive map integration would be placed here</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* FAQ Quick Links */}
        <div className="mt-16 text-center">
          <h2 className="text-2xl font-bold text-amber-900 mb-4">Frequently Asked Questions</h2>
          <p className="text-amber-700 mb-6">
            Looking for quick answers? Check out our FAQ section for common questions about our products, delivery, and
            ordering process.
          </p>
          <Button variant="outline" className="border-orange-600 text-orange-600 hover:bg-orange-50 bg-transparent">
            View FAQ
          </Button>
        </div>
      </div>
    </div>
  )
}
