import Image from "next/image"
import { Heart, Award, Users, Leaf } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export const metadata = {
  title: "About Us - Bhanja Ko Khuwa | Our Story & Traditional Methods",
  description:
    "Learn about Bhanja Ko Khuwa's journey, our traditional dairy-making methods, and commitment to quality. Family-owned business serving authentic Nepali dairy products since generations.",
}

export default function AboutPage() {
  const values = [
    {
      icon: Heart,
      title: "Family Tradition",
      description: "Recipes and methods passed down through generations of dairy artisans",
    },
    {
      icon: Award,
      title: "Premium Quality",
      description: "Only the finest ingredients and traditional techniques for superior taste",
    },
    {
      icon: Users,
      title: "Community Focus",
      description: "Supporting local farmers and serving our community with pride",
    },
    {
      icon: Leaf,
      title: "Natural Process",
      description: "No artificial preservatives, just pure and natural dairy goodness",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-50">
      {/* Hero Section */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold text-amber-900 mb-6">Our Story</h1>
              <p className="text-lg text-amber-800 mb-6 leading-relaxed">
                भान्जाको खुवा (Bhanja Ko Khuwa) began as a small family venture rooted in the rich dairy traditions of
                Nepal. What started in our grandmother's kitchen has grown into a trusted name for authentic Nepali
                dairy products.
              </p>
              <p className="text-lg text-amber-800 mb-6 leading-relaxed">
                The name "Bhanja Ko Khuwa" translates to "Nephew's Khuwa" - a loving reference to how our family recipes
                were carefully taught and preserved by our elders, ensuring that each generation maintains the authentic
                taste and quality our customers have come to love.
              </p>
              <p className="text-lg text-amber-800 leading-relaxed">
                Today, we continue this legacy by combining traditional methods with modern hygiene standards, bringing
                you the pure, authentic taste of Nepal's finest dairy products.
              </p>
            </div>
            <div className="relative">
              <Image
                src="/placeholder.svg?height=500&width=500"
                alt="Traditional Khuwa Making Process"
                width={500}
                height={500}
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-6 -right-6 bg-white p-4 rounded-xl shadow-lg">
                <p className="font-semibold text-amber-900">Since 1985</p>
                <p className="text-sm text-orange-600">Three Generations</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-amber-900 mb-4">Our Values</h2>
            <p className="text-lg text-amber-700 max-w-2xl mx-auto">
              The principles that guide everything we do, from sourcing to serving
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="text-center border-0 shadow-lg bg-gradient-to-b from-amber-50 to-orange-50">
                <CardContent className="p-6">
                  <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <value.icon className="w-8 h-8 text-orange-600" />
                  </div>
                  <h3 className="text-xl font-bold text-amber-900 mb-3">{value.title}</h3>
                  <p className="text-amber-700">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-amber-900 mb-4">Our Traditional Process</h2>
            <p className="text-lg text-amber-700 max-w-2xl mx-auto">
              From farm to table, every step is carefully crafted to ensure the highest quality
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-orange-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                1
              </div>
              <h3 className="text-xl font-bold text-amber-900 mb-3">Fresh Milk Collection</h3>
              <p className="text-amber-700">
                We source fresh, high-quality milk from trusted local farms in the Kathmandu Valley, ensuring the best
                foundation for our products.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-orange-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                2
              </div>
              <h3 className="text-xl font-bold text-amber-900 mb-3">Traditional Cooking</h3>
              <p className="text-amber-700">
                Using time-honored methods, we slowly cook the milk in large copper vessels, stirring continuously to
                achieve the perfect texture and flavor.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-orange-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                3
              </div>
              <h3 className="text-xl font-bold text-amber-900 mb-3">Quality Packaging</h3>
              <p className="text-amber-700">
                Each product is carefully packaged to maintain freshness and quality, ready to bring the authentic taste
                of Nepal to your home.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-amber-900 mb-4">Meet Our Family</h2>
            <p className="text-lg text-amber-700">The dedicated people behind Bhanja Ko Khuwa</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="text-center border-0 shadow-lg">
              <CardContent className="p-6">
                <Image
                  src="/placeholder.svg?height=200&width=200"
                  alt="Grandmother - Founder"
                  width={200}
                  height={200}
                  className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
                />
                <h3 className="text-xl font-bold text-amber-900 mb-2">आमा (Grandmother)</h3>
                <p className="text-orange-600 mb-3">Founder & Recipe Keeper</p>
                <p className="text-amber-700 text-sm">
                  The heart of our operation, preserving traditional recipes and ensuring every batch meets her exacting
                  standards.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center border-0 shadow-lg">
              <CardContent className="p-6">
                <Image
                  src="/placeholder.svg?height=200&width=200"
                  alt="Father - Production Manager"
                  width={200}
                  height={200}
                  className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
                />
                <h3 className="text-xl font-bold text-amber-900 mb-2">बुबा (Father)</h3>
                <p className="text-orange-600 mb-3">Production Manager</p>
                <p className="text-amber-700 text-sm">
                  Oversees daily production and maintains relationships with our network of local dairy farmers.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center border-0 shadow-lg">
              <CardContent className="p-6">
                <Image
                  src="/placeholder.svg?height=200&width=200"
                  alt="Son - Business Development"
                  width={200}
                  height={200}
                  className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
                />
                <h3 className="text-xl font-bold text-amber-900 mb-2">छोरा (Son)</h3>
                <p className="text-orange-600 mb-3">Business Development</p>
                <p className="text-amber-700 text-sm">
                  Brings modern business practices while respecting traditional methods, expanding our reach to serve
                  more families.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
