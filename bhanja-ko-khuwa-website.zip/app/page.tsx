import Image from "next/image"
import Link from "next/link"
import { Star, MapPin, Phone, Clock, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function HomePage() {
  const featuredProducts = [
    {
      id: 1,
      name: "Premium Khuwa",
      description: "Traditional handmade khuwa from fresh buffalo milk",
      price: "NPR 450/kg",
      image: "/placeholder.svg?height=300&width=300",
      badge: "Best Seller",
    },
    {
      id: 2,
      name: "Special Gudpāk",
      description: "Sweet delicacy made with pure khuwa and jaggery",
      price: "NPR 650/kg",
      image: "/placeholder.svg?height=300&width=300",
      badge: "Traditional",
    },
    {
      id: 3,
      name: "Fresh Paneer",
      description: "Soft cottage cheese made daily from local milk",
      price: "NPR 380/kg",
      image: "/placeholder.svg?height=300&width=300",
      badge: "Daily Fresh",
    },
  ]

  const testimonials = [
    {
      name: "Sita Sharma",
      location: "Kathmandu",
      text: "भान्जाको खुवाको स्वाद नै फरक छ। घरमै बनाएको जस्तै!",
      rating: 5,
    },
    {
      name: "Ram Bahadur",
      location: "Pokhara",
      text: "Best quality khuwa in the valley. Always fresh and authentic taste.",
      rating: 5,
    },
    {
      name: "Maya Gurung",
      location: "Lalitpur",
      text: "गुडपाकको मिठास र खुवाको गुणस्तर उत्कृष्ट छ।",
      rating: 5,
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-50">
      {/* Hero Section */}
      <section className="relative py-20 px-4 text-center bg-gradient-to-r from-amber-100 via-orange-100 to-yellow-100">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="text-left">
              <h1 className="text-4xl md:text-6xl font-bold text-amber-900 mb-6">
                भान्जाको खुवा
                <span className="block text-2xl md:text-3xl text-orange-700 mt-2">Bhanja Ko Khuwa</span>
              </h1>
              <p className="text-lg md:text-xl text-amber-800 mb-8 leading-relaxed">
                Authentic Nepali dairy products made with love and tradition. From our family to yours, experience the
                pure taste of handcrafted khuwa, gudpāk, and fresh dairy delights.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="bg-orange-600 hover:bg-orange-700 text-white">
                  <Link href="/products">
                    <ArrowRight className="w-5 h-5 mr-2" />
                    Shop Now
                  </Link>
                </Button>
                <Button
                  asChild
                  variant="outline"
                  size="lg"
                  className="border-orange-600 text-orange-600 hover:bg-orange-50 bg-transparent"
                >
                  <Link href="/about">Learn Our Story</Link>
                </Button>
              </div>
            </div>
            <div className="relative">
              <Image
                src="/placeholder.svg?height=500&width=500"
                alt="Traditional Khuwa Making Process"
                width={500}
                height={500}
                className="rounded-2xl shadow-2xl"
                priority
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-xl shadow-lg">
                <div className="flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-orange-600" />
                  <span className="font-semibold text-amber-900">Made in Nepal</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-amber-900 mb-4">Featured Products</h2>
            <p className="text-lg text-amber-700 max-w-2xl mx-auto">
              Discover our signature dairy products, crafted using traditional methods passed down through generations
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredProducts.map((product) => (
              <Card
                key={product.id}
                className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg bg-white"
              >
                <CardContent className="p-0">
                  <div className="relative overflow-hidden rounded-t-lg">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      width={300}
                      height={300}
                      className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-4 left-4">
                      <span className="bg-orange-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
                        {product.badge}
                      </span>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-amber-900 mb-2">{product.name}</h3>
                    <p className="text-amber-700 mb-4">{product.description}</p>
                    <div className="flex justify-between items-center">
                      <span className="text-2xl font-bold text-orange-600">{product.price}</span>
                      <Button size="sm" className="bg-orange-600 hover:bg-orange-700">
                        Order Now
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-orange-600 text-orange-600 hover:bg-orange-50 bg-transparent"
            >
              <Link href="/products">View All Products</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-amber-900 mb-4">Why Choose Bhanja Ko Khuwa?</h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-bold text-amber-900 mb-2">Traditional Methods</h3>
              <p className="text-amber-700">Time-honored techniques passed down through generations</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-bold text-amber-900 mb-2">Local Sourcing</h3>
              <p className="text-amber-700">Fresh milk from local farms in the Kathmandu Valley</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-bold text-amber-900 mb-2">Premium Quality</h3>
              <p className="text-amber-700">No preservatives, just pure and natural ingredients</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Phone className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-bold text-amber-900 mb-2">Personal Service</h3>
              <p className="text-amber-700">Family-run business with personalized customer care</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 px-4 bg-gradient-to-r from-amber-50 to-orange-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-amber-900 mb-4">What Our Customers Say</h2>
            <p className="text-lg text-amber-700">Trusted by families across Nepal and beyond</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-white shadow-lg border-0">
                <CardContent className="p-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-orange-400 text-orange-400" />
                    ))}
                  </div>
                  <p className="text-amber-800 mb-4 italic">"{testimonial.text}"</p>
                  <div>
                    <p className="font-semibold text-amber-900">{testimonial.name}</p>
                    <p className="text-sm text-amber-600">{testimonial.location}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-orange-600 to-amber-600 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Taste Tradition?</h2>
          <p className="text-xl mb-8 opacity-90">Order fresh khuwa and dairy products delivered to your doorstep</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-white text-orange-600 hover:bg-gray-100">
              <Link href="/order">
                <Phone className="w-5 h-5 mr-2" />
                Order Now
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-orange-600 bg-transparent"
            >
              <Link href="/contact">Contact Us</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
